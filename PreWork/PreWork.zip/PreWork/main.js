let testBtn = document.getElementById("tester")

testBtn.addEventListener("mousedown", function() {
    testBtn.textContent = 'Button clicked'; 
})